package com.example.metro

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private val palette = linkedMapOf(
        "cobalt" to "#0050EF", "magenta" to "#D80073", "lime" to "#A4C400",
        "teal" to "#00ABA9", "orange" to "#FA6800", "purple" to "#6A00FF",
        "red" to "#E51400", "green" to "#60A917", "mango" to "#F0A30A", "steel" to "#647687"
    )
    private var accent = Color.parseColor("#0050EF")

    private class App(val label: String, val pkg: String, val icon: Drawable)

    private var apps = listOf<App>()
    private lateinit var grid: GridLayout
    private lateinit var listHost: LinearLayout
    private lateinit var search: EditText
    private lateinit var pager: HorizontalScrollView
    private var clockTime: TextView? = null
    private var clockDate: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("metro", MODE_PRIVATE) }
    private val screenW by lazy { resources.displayMetrics.widthPixels }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { loadApps() }
    }

    private val tick = object : Runnable {
        override fun run() { updateClock(); handler.postDelayed(this, 15000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        accent = prefs.getInt("accent", accent)
        buildUi()
        loadApps()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(pkgReceiver, f)
    }

    override fun onDestroy() { super.onDestroy(); unregisterReceiver(pkgReceiver) }
    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        search.setText("")
        pager.smoothScrollTo(0, 0)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { search.setText(""); pager.smoothScrollTo(0, 0) }

    private fun light(tv: TextView, sp: Float) {
        tv.setTextColor(Color.WHITE)
        tv.textSize = sp
        tv.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    }

    // ---------- UI ----------

    private fun buildUi() {
        val startScroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val startCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(24), dp(12), dp(32))
        }
        val title = TextView(this).apply {
            text = "start"; light(this, 40f); setPadding(dp(8), 0, 0, dp(12))
            setOnLongClickListener { settingsMenu(); true }
        }
        grid = GridLayout(this).apply { columnCount = 4 }
        val arrow = TextView(this).apply {
            text = "\u2192"; light(this, 22f); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setStroke(dp(2), Color.WHITE); setColor(Color.TRANSPARENT) }
            setOnClickListener { pager.smoothScrollTo(screenW, 0) }
        }
        startCol.addView(title)
        startCol.addView(grid)
        startCol.addView(arrow, LinearLayout.LayoutParams(dp(44), dp(44)).apply {
            gravity = Gravity.END; topMargin = dp(16); rightMargin = dp(6)
        })
        startScroll.addView(startCol)

        val listScroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val listCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(12), dp(24))
        }
        val title2 = TextView(this).apply {
            text = "apps"; light(this, 40f)
            setOnLongClickListener { settingsMenu(); true }
        }
        search = EditText(this).apply {
            hint = "search"; setHintTextColor(0xFF888888.toInt()); setTextColor(Color.WHITE)
            textSize = 18f; setSingleLine(true)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF888888.toInt())
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { renderList() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        listHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listCol.addView(title2); listCol.addView(search); listCol.addView(listHost)
        listScroll.addView(listCol)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(startScroll, LinearLayout.LayoutParams(screenW, ViewGroup.LayoutParams.MATCH_PARENT))
        row.addView(listScroll, LinearLayout.LayoutParams(screenW, ViewGroup.LayoutParams.MATCH_PARENT))

        pager = object : HorizontalScrollView(this) {
            override fun onTouchEvent(e: MotionEvent): Boolean {
                val r = super.onTouchEvent(e)
                if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) {
                    post { smoothScrollTo(if (scrollX > screenW / 4) screenW else 0, 0) }
                }
                return r
            }
        }.apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setBackgroundColor(Color.BLACK)
            addView(row)
        }
        setContentView(pager)
    }

    // ---------- data ----------

    private fun loadApps() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(q, 0)
            .map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        if (!prefs.contains("pins")) resetStart()
        renderAll()
    }

    private fun resetStart() {
        val e = prefs.edit()
        prefs.all.keys.filter { it.startsWith("size_") }.forEach { e.remove(it) }
        e.putString("pins", apps.take(9).joinToString("\n") { it.pkg }).apply()
    }

    private fun pins() = (prefs.getString("pins", "") ?: "").split("\n").filter { it.isNotEmpty() }
    private fun savePins(l: List<String>) = prefs.edit().putString("pins", l.joinToString("\n")).apply()
    private fun sizeOf(a: App) = prefs.getString("size_${a.pkg}", "m") ?: "m"

    private fun launch(a: App) {
        packageManager.getLaunchIntentForPackage(a.pkg)?.let { startActivity(it) }
    }

    private fun renderAll() { renderTiles(); renderList() }

    // ---------- menus ----------

    private fun dialog(title: String, items: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(title).setItems(items.toTypedArray()) { _, i -> onPick(i) }.show()
    }

    private fun settingsMenu() {
        dialog("settings", listOf("accent color", "reset start")) { i ->
            if (i == 0) {
                dialog("accent color", palette.keys.toList()) { c ->
                    accent = Color.parseColor(palette.values.elementAt(c))
                    prefs.edit().putInt("accent", accent).apply()
                    renderAll()
                }
            } else { resetStart(); renderAll() }
        }
    }

    private fun menu(a: App) {
        val pinned = pins().contains(a.pkg)
        val names = mutableListOf<String>()
        val acts = mutableListOf<() -> Unit>()
        fun add(n: String, f: () -> Unit) { names += n; acts += f }
        if (pinned) {
            add("unpin from start") { savePins(pins() - a.pkg); renderTiles() }
            add("resize (${sizeOf(a)})") {
                val next = when (sizeOf(a)) { "s" -> "m"; "m" -> "w"; else -> "s" }
                prefs.edit().putString("size_${a.pkg}", next).apply(); renderTiles()
            }
            add("move earlier") { move(a, -1) }
            add("move later") { move(a, 1) }
        } else add("pin to start") { savePins(pins() + a.pkg); renderTiles() }
        add("app info") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
        }
        add("uninstall") { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}"))) }
        dialog(a.label.lowercase(), names) { acts[it]() }
    }

    private fun move(a: App, d: Int) {
        val l = pins().toMutableList()
        val i = l.indexOf(a.pkg); val j = i + d
        if (i < 0 || j < 0 || j >= l.size) return
        l[i] = l[j].also { l[j] = l[i] }
        savePins(l); renderTiles()
    }

    // ---------- tiles ----------

    private fun updateClock() {
        val now = Date()
        clockTime?.text = SimpleDateFormat("H:mm", Locale.getDefault()).format(now)
        clockDate?.text = SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(now).lowercase()
    }

    private fun cellParams(cs: Int, rs: Int): GridLayout.LayoutParams {
        val m = dp(3)
        val unit = (screenW - dp(24)) / 4 - 2 * m
        return GridLayout.LayoutParams(
            GridLayout.spec(GridLayout.UNDEFINED, rs), GridLayout.spec(GridLayout.UNDEFINED, cs)
        ).apply {
            width = cs * (unit + 2 * m) - 2 * m
            height = rs * (unit + 2 * m) - 2 * m
            setMargins(m, m, m, m)
        }
    }

    private fun renderTiles() {
        grid.removeAllViews()
        grid.addView(clockTile())
        for (p in pins()) {
            val a = apps.find { it.pkg == p } ?: continue
            grid.addView(tile(a))
        }
        updateClock()
    }

    private fun clockTile(): View {
        val f = FrameLayout(this).apply { setBackgroundColor(accent); layoutParams = cellParams(4, 2) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(14), dp(10)) }
        clockTime = TextView(this).apply { light(this, 56f) }
        clockDate = TextView(this).apply { light(this, 15f) }
        col.addView(clockTime); col.addView(clockDate)
        f.addView(col, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM or Gravity.START))
        f.setOnClickListener {
            startActivity(Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        press(f)
        return f
    }

    private fun tile(a: App): View {
        val size = sizeOf(a)
        val cs = when (size) { "w" -> 4; "s" -> 1; else -> 2 }
        val rs = if (size == "s") 1 else 2
        val f = FrameLayout(this).apply { setBackgroundColor(accent); layoutParams = cellParams(cs, rs) }
        val h = f.layoutParams.height
        val iconSize = if (size == "s") h * 11 / 20 else h * 2 / 5
        f.addView(ImageView(this).apply { setImageDrawable(a.icon) },
            FrameLayout.LayoutParams(iconSize, iconSize, Gravity.CENTER))
        if (size != "s") {
            f.addView(TextView(this).apply {
                text = a.label.lowercase(); light(this, 13f); maxLines = 1
                setPadding(dp(8), 0, dp(8), dp(6))
            }, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM or Gravity.START))
        }
        f.setOnClickListener { launch(a) }
        f.setOnLongClickListener { menu(a); true }
        press(f)
        return f
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun press(f: View) {
        f.cameraDistance = 9000f * resources.displayMetrics.density
        f.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    v.scaleX = 0.94f; v.scaleY = 0.94f
                    v.rotationY = (e.x / v.width - 0.5f) * -18f
                    v.rotationX = (e.y / v.height - 0.5f) * 18f
                }
                else -> v.animate().scaleX(1f).scaleY(1f).rotationX(0f).rotationY(0f).setDuration(120).start()
            }
            false
        }
    }

    // ---------- app list ----------

    private fun renderList() {
        listHost.removeAllViews()
        val filter = search.text.toString().trim()
        var last = ""
        for (a in apps) {
            if (filter.isNotEmpty() && !a.label.contains(filter, true)) continue
            if (filter.isEmpty()) {
                val c = a.label.firstOrNull()?.uppercaseChar()?.takeIf { it.isLetter() }?.toString() ?: "#"
                if (c != last) {
                    last = c
                    listHost.addView(TextView(this).apply {
                        text = c.lowercase(); light(this, 26f); setTextColor(accent)
                        setPadding(0, dp(14), 0, dp(2))
                    })
                }
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            val box = FrameLayout(this).apply { setBackgroundColor(accent) }
            box.addView(ImageView(this).apply { setImageDrawable(a.icon) },
                FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
            row.addView(box, LinearLayout.LayoutParams(dp(48), dp(48)))
            row.addView(TextView(this).apply {
                text = a.label.lowercase(); light(this, 22f); setPadding(dp(16), 0, 0, 0)
            })
            row.setOnClickListener { launch(a) }
            row.setOnLongClickListener { menu(a); true }
            listHost.addView(row)
        }
    }
}
